# Bajwa CPA Premium WordPress Theme

A custom, dependency-free WordPress theme for Bajwa CPA Professional Corporation.

## Install

1. Copy this folder to `wp-content/themes/bajwa-premium`.
2. Activate **Bajwa CPA Premium** in Appearance → Themes.
3. Activation creates the homepage, navigation, service pages, resource pages, three hero slides and imports the 33 supplied articles.
4. If content was not created (for example, the theme was already active during development), visit Appearance → Bajwa Theme Setup and select **Create website content**.
5. Visit Settings → Permalinks and save once if service URLs return 404.

## Edit the hero

In WordPress admin, open **Hero Slides**. Each slide uses:

- Title for the heading
- Featured Image for the background image
- Slide content fields for the eyebrow, supporting paragraph, button label, button URL and focal point
- Page Attributes → Order for display order

The first slide is server-rendered with an eager, high-priority responsive image. Later images lazy-load. The carousel uses lightweight vanilla JavaScript and no slider library.

## Edit page and service imagery

Every standard page and service uses its WordPress **Featured Image** as the designed page-header image. Replace it from the page or service editor. The theme setup imports the supplied, rights-safe generated photography into the Media Library and assigns meaningful alt text. If no Featured Image is selected, an optimized theme image is used as a fallback.

## Motion and loading states

Section entrances are lightweight progressive enhancements. Content starts in the HTML and remains visible when JavaScript is unavailable. Each element animates only once and all non-essential motion is disabled when `prefers-reduced-motion` is enabled.

There is no page-covering loader. The branded Bajwa CPA indicator appears only while a valid contact form is being submitted.

## Performance verification

PHP and JavaScript syntax have been validated locally. A meaningful Largest Contentful Paint number requires the theme to be installed on its final WordPress host because server response time, page caching, plugins, CDN configuration and network conditions all affect LCP. Run Lighthouse against the deployed homepage on mobile and desktop; the expected LCP element is the first hero image or H1. Record the median of at least three runs.

Recommended production configuration: full-page caching, Brotli/Gzip, long cache headers for theme assets, HTTP/2 or HTTP/3, and WebP/AVIF generation for future Media Library uploads.
